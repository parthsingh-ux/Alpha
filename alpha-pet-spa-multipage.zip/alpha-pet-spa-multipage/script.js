document.addEventListener('DOMContentLoaded',()=>{const b=document.querySelector('.menu-btn'),n=document.querySelector('.nav');if(b&&n)b.addEventListener('click',()=>{const o=n.classList.toggle('open');b.setAttribute('aria-expanded',o);b.innerHTML=o?'<i class="ti ti-x"></i>':'<i class="ti ti-menu-2"></i>';});const f=document.querySelector('form[data-demo]');if(f)f.addEventListener('submit',e=>{e.preventDefault();if(!f.reportValidity())return;f.innerHTML='<div class="sent"><i class="ti ti-circle-check"></i><h3>Thanks! We\'ve got your message.</h3><p>The Alpha Pet Spa team will be in touch during business hours.</p></div>';});});

// Close the mobile menu after following an in-page link.
document.addEventListener('DOMContentLoaded', () => {
  const nav = document.querySelector('.nav');
  const button = document.querySelector('.menu-btn');
  if (!nav || !button) return;
  nav.addEventListener('click', event => {
    if (!event.target.closest('a')) return;
    nav.classList.remove('open');
    button.setAttribute('aria-expanded', 'false');
    button.innerHTML = '<i class="ti ti-menu-2"></i>';
  });
});
