# Alpha Pet Spa · Website (Site 01)
Des 153-27 · 4 October 2026 · Language en-AU · Maitland NSW

## Contents
- `html/` — 5 pages: `index.html` (Home), `services.html`, `pricing-cancellation-policy.html`, `about-us.html`, `contact.html`
- `css/site.css` — all styles (one sheet)
- `js/site.js` — mobile menu + contact form demo submit
- `images/` — 23 web-optimised WebP photos + 2 logo PNGs (deep blue, white)
- `../Alpha Pet Spa - Standalone.html` — single offline file with all 5 pages (hash navigation). For review only.

To preview: open `html/index.html` in a browser. To deploy: put the pages at the web root and keep the `css/`, `js/`, `images/` paths as `../` or move them alongside and update the paths.

## Design
- Custom direction (brief: no template). Approved direction board: `../mock/Alpha Pet Spa - Direction Board v1.png`
- Colours: Pale blue #D6EAF8 · Sky #3E86D0 · Deep blue #1F3F7A · Purple (CTA) #7B4FC9 · Lilac #E9DFF8 · White #FBFCFE · Sunshine #FFD66B (stickers/stars only)
- Type: Fredoka (headings) · Figtree (body) — Google Fonts
- Icons: Tabler Icons webfont 3.19.0 (one rounded outline family)

## SEO / AEO / GEO
- Unique title, meta description, canonical and Open Graph tags on every page
- Structured data: LocalBusiness on every page; ItemList of Services on Services; FAQPage on Home (5) and Pricing (5)
- FAQs split by topic so each answer appears on one page only
- Every image has a descriptive filename and alt text (see `IMAGE_REGISTER.md`)

## Before launch (open items)
1. **Booking link** — every Book Now goes to `contact.html#book` until the booking platform is known.
2. **Contact form** — demo submit only. Connect a form handler (e.g. hosting form service) to info@alphapetspa.com.au.
3. **Prices** — taken from the current site; replace with the client brochure. "To confirm" labels mark them.
4. **Google Reviews** — 3 placeholder cards + "Read all reviews" button need the GBP link or a reviews widget.
5. **Team** — 6 placeholder pods (Lorem Ipsum) per brief; client to supply photos, names, roles, fun facts. Confirm the team photo is current (shows COVID-era signage).
6. **Logo** — recoloured from a 193px file. Replace with vector (SVG/AI/EPS). Favicon to be simplified.
7. **Hours** — using the current site (Fri until 4:30pm); the brief also says Mon–Fri 8–4. Confirm.
8. **Privacy Policy** — footer links to the current site's privacy page; carry it over or recreate.
9. **Image rights** — confirm ownership of possible customer photos (bulldog, High Street groodle). Unsplash ID needed for the shampoo bath stock image.
10. **Cats** — brief lists cat grooming; the site is dog-only, as the rest of the brief describes. Confirm.
11. Remove remaining `.todo` labels once each item is resolved.
