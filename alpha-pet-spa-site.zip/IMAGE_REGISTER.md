# Alpha Pet Spa · Image register
Source: client Google Business Profile (via Rajeev, 4 Oct 2026). Des 153-27.
All files convert to WebP at build (srcset 480/960/1440). Filenames final.

| File | Size | Use | Alt text | Title / caption |
|---|---|---|---|---|
| cavoodle-groom-rainbow-bandana-maitland | 1440×1800 | **Home hero** (blob) | Happy apricot cavoodle with a fresh teddy groom and rainbow star bandana on the grooming table at Alpha Pet Spa, Maitland | Fresh groom, big smile |
| dog-bath-purple-tub | 2164×1290 | Services · Bath & Dry | Groomer gently rinsing a relaxed golden dog in a purple hydrobath at Alpha Pet Spa | Bath time in the purple tub |
| pomeranian-deshed-fluffy-coat | 1440×1800 | Services · Deshedding | Fluffy orange Pomeranian after a deshedding treatment, smiling on the grooming table | Deshed and fluffed |
| corgi-cross-short-clip-standard-groom | 1218×810 | Services · Standard Groom | Corgi cross with a neat short all-over clip and white socks after a standard groom | Standard groom |
| white-groodle-teddy-groom | 979×1020 | Services · Deluxe Groom | White groodle with a rounded teddy-style face and tidy legs after a deluxe groom | Teddy trim |
| maltese-hand-scissored-blue-bow | 1170×1462 | Services · Hand Scissoring | Fluffy white Maltese with a hand-scissored coat and a blue paw-print bow | Hand scissored, finished with a bow |
| shih-tzu-face-tidy-bandana | 678×1020 | Services · Mini Tidy & add-ons | Shih tzu with a tidied face, eyes and feet, wearing a skull-print bandana | Mini tidy |
| golden-retriever-happy-after-groom | 2014×1074 | Pricing & Cancellation · banner | Golden retriever squinting happily with tongue out in a bone-print bandana after his groom | Happy after a bath and brush out |
| two-small-dogs-teddy-trims | 1360×904 | Home · intro | Two small fluffy dogs sitting side by side with matching teddy trims on the grooming table | Grooming buddies |
| groomer-christian-ear-muffs-curly-dog | 2004×1072 | About · our approach | Groomer wearing ear muffs while brushing a curly black dog at Alpha Pet Spa | Calm, careful grooming |
| alpha-pet-spa-team-with-dogs | 2946×1524 | Home · team teaser + About hero | The Alpha Pet Spa team in the Maitland salon, each holding a freshly groomed dog | The Alpha Pet Spa team |
| groodle-high-street-maitland | 765×1020 | Contact | Freshly groomed white groodle in a blue bandana sitting outside on High Street, Maitland | Ready for pick-up on High Street |
| golden-groodle-full-groom | 1218×810 | Services · page header | Golden groodle with a full body groom standing on the grooming table | Full groom |
| maltese-sudsy-bath | 678×1020 | Instagram grid | Small white Maltese covered in suds during a bath | Sudsy |
| cavalier-king-charles-tongue-out | 1360×904 | Instagram grid | Black and tan Cavalier King Charles spaniel licking his nose after a groom | Cheeky Cav |
| miniature-schnauzer-breed-trim | 678×1020 | Instagram grid | Miniature schnauzer with a classic breed trim and skull bandana | Schnauzer trim |
| black-poodle-cross-tidy-groom | 678×1020 | Instagram grid | Black and tan poodle cross with a rounded face after a tidy groom | Tidy and round |
| shaggy-terrier-cross-tidy | 678×1020 | Instagram grid | Grey terrier cross with a short body clip and fluffy ears | Short and shaggy |
| british-bulldog-puppy-bandana | 779×1020 | Instagram grid | British bulldog puppy in a candy-cane bandana sitting on the grass | Bandana season |
| team-member-dachshund-cropped | 2016×1214 | **Not used** | — | Face cropped at eyes |

## Stock (Unsplash · Rajeev, 4 Oct 2026) — detail use only, never a groom result
| File | Use | Alt text | Source |
|---|---|---|---|
| stock-nail-clipping-white-dog-paw.jpg | Services · Nails | Groomer's hands carefully trimming a white dog's nails with clippers | Unsplash · Getty Images · QbF88NsRSRI |
| stock-groomer-holding-yorkie-paw.jpg | Services · Mini Tidy & add-ons (feet & pads) | Groomer gently holding a Yorkshire terrier's paw during a tidy | Unsplash · Getty Images · 8Ci5GE3JZh8 |
| stock-dog-lathered-shampoo-bath.png | Home · USP "Quality grooming products" | Dog's coat lathered in gentle shampoo during a bath | Unsplash (Rajeev to confirm photo ID) |

Omitted: barber tools flat lay (human barber kit, dark, visible brands); clipper on black cat (cat, clinical).
Still to source: pet tools flat lay (light background) for the Pricing & Cancellation header. Fallback: golden retriever banner.

## On hold (not used)
- `_hold/bichon-on-lap-likely-stock` — soft, upscaled, not in salon; same image appears on the current template site. Likely stock. Rights unconfirmed.
- `_hold/poodle-puppy-gift-box-likely-stock` — Christmas styling; also on the current template site. Likely stock. Rights unconfirmed.

## Duplicates dropped
- pasted-1791052995199 = cavoodle hero
- pasted-1791053182277 = Christian grooming
